#!/bin/bash
# PushBar installer — copies the app to ~/Applications and launches it.
cd "$(dirname "$0")"
fail() {
  echo
  echo "Error $1: $2"
  echo "Look up this code on the PushBar error list:"
  echo "  https://github.com/jonpikereally/Push3InterfaceControl/blob/main/ERRORS.md"
  echo "(You can also give that page to an AI assistant for help.)"
  exit 1
}
echo "Installing PushBar…"
mkdir -p ~/Applications || fail PB-601 "Couldn't create ~/Applications."
rm -rf ~/Applications/PushBar.app
ditto --norsrc PushBar.app ~/Applications/PushBar.app \
  || fail PB-601 "Couldn't copy PushBar into ~/Applications."
# Clear the download quarantine and re-sign locally so macOS trusts it on this Mac.
xattr -dr com.apple.quarantine ~/Applications/PushBar.app 2>/dev/null
codesign --force --sign - ~/Applications/PushBar.app 2>/dev/null \
  || fail PB-602 "Couldn't sign PushBar for this Mac."
open ~/Applications/PushBar.app \
  || fail PB-603 "PushBar was installed but couldn't be opened. Open it from ~/Applications yourself."
echo
echo "Done! Look for the pad-grid icon in your menu bar."
