PushBar v1.0 — menu bar control for Ableton Push 3's audio interface
on macOS (13+), without Ableton Live running
https://github.com/jonpikereally/Push3InterfaceControl

INSTALL
Double-click "Install PushBar.command".
If macOS blocks it: right-click it, choose Open, then Open again.

USE
• Plug Push 3 into the Mac over USB-C. If you've just quit Live and Push
  has gone dark, unplug its USB cable and plug it back in.
• Click the menu bar icon: Master, Main Out and Headphones levels with
  mute, Input 1/2 gain (0 to +20 dB) with mute, and a link button to move
  left and right separately
• Mac Output / Mac Input make Push the Mac's sound output or input
• Sample Rate: 44.1 / 48 / 88.2 / 96 kHz
• The Mac's own volume keys move Master while Push is the sound output

PRIVACY
PushBar only talks to Push through macOS's audio system. No accounts, no
analytics. The only thing it fetches from the internet is a small version
file from the GitHub repo above, to see whether an update exists.
